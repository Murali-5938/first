from django.shortcuts import render

# Create your views here.
from app.forms import *
from app.models import *
from django.http import HttpResponse

def insert_school(request):
    ESFO=SchoolForm()
    d={'ESFO':ESFO}

    if request.method=='POST':
        SFDO=SchoolForm(request.POST)
        if SFDO.is_valid():
            sn=SFDO.cleaned_data['scname']
            sl=SFDO.cleaned_data['sclocation']
            sp=SFDO.cleaned_data['scprincipal']

            TSO=School.objects.get_or_create(scname=sn,sclocation=sl,scprincipal=sp)
            return HttpResponse('School is Created')

    return render(request,'insert_school.html',d)


def insert_student(request):
    ESTFO=StudentForm()
    d={'ESTFO':ESTFO}

    if request.method=='POST':
        STFDO=StudentForm(request.POST)
        if STFDO.is_valid():
            SCO=STFDO.cleaned_data['scname']
            
            stn=STFDO.cleaned_data['stname']
            sta=STFDO.cleaned_data['stage']
            TSO=Student.objects.get_or_create(scname=SCO,stname=stn,stage=sta)
            return HttpResponse('Student is Craeted')
    
    return render(request,'insert_student.html',d)












