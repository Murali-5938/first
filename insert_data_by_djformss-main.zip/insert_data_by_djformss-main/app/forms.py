from django import forms
from app.models import *

class SchoolForm(forms.Form):
    scname=forms.CharField()
    sclocation=forms.CharField()
    scprincipal=forms.CharField()

class StudentForm(forms.Form):
    scname=forms.ModelChoiceField(queryset=School.objects.all())
    stname=forms.CharField()
    stage=forms.IntegerField()