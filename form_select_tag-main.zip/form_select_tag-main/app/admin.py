from django.contrib import admin
from app.models import *
# Register y models here.
admin.site.register(Topic)
admin.site.register(Webpage)
admin.site.register(AccessRecords)
